<?php

namespace App\SupportedApps\Yacht;

class Yacht extends \App\SupportedApps
{
}
