<?php namespace App\SupportedApps\Kaizoku;

class Kaizoku extends \App\SupportedApps {

}