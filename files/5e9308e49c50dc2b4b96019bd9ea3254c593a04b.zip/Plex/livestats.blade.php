<ul class="livestats">
    <li>
        <span class="title">{!! $section_1_title ?? '' !!}</span>
        <strong>{!! $section_1_number ?? '' !!}</strong>
    </li>
    <li>
        <span class="title">{!! $section_2_title ?? '' !!}</span>
        <strong>{!! $section_2_number ?? '' !!}</strong>
    </li>

</ul>
