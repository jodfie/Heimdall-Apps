<?php

namespace App\SupportedApps\Authelia;

class Authelia extends \App\SupportedApps
{
}
