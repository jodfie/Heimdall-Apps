<?php namespace App\SupportedApps\sftpgo;

class sftpgo extends \App\SupportedApps {

}