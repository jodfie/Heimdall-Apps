<?php namespace App\SupportedApps\openHAB;

class openHAB extends \App\SupportedApps
{
}
