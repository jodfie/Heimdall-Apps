<?php

namespace App\SupportedApps\OwnPhotos;

class OwnPhotos extends \App\SupportedApps
{
}
