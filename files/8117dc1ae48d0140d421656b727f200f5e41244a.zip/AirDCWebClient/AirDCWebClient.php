<?php namespace App\SupportedApps\AirDCWebClient;

class AirDCWebClient extends \App\SupportedApps {

}