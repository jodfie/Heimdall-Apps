<?php namespace App\SupportedApps\Nitter;

class Nitter extends \App\SupportedApps {

}