<ul class="livestats">
    <li>
        <span class="title">Rules</span>
        <strong>{!! $activeRules !!}<span>/{!! $rules !!}</span></strong>
    </li>
</ul>
