<?php namespace App\SupportedApps\Clarkson;

class Clarkson extends \App\SupportedApps
{
}
