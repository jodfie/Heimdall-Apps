<?php

namespace App\SupportedApps\RdioScanner;

class RdioScanner extends \App\SupportedApps
{
}
