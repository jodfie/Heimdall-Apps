<?php

namespace App\SupportedApps\CodiMD;

class CodiMD extends \App\SupportedApps
{
}
