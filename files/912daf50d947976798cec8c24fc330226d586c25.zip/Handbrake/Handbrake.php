<?php namespace App\SupportedApps\Handbrake;

class Handbrake extends \App\SupportedApps {

}