<?php namespace App\SupportedApps\MediaElch;

class MediaElch extends \App\SupportedApps {

}