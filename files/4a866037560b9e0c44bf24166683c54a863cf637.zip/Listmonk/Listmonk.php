<?php

namespace App\SupportedApps\Listmonk;

class Listmonk extends \App\SupportedApps
{
}
