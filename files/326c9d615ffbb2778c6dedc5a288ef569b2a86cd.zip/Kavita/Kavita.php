<?php namespace App\SupportedApps\Kavita;

class Kavita extends \App\SupportedApps {

}