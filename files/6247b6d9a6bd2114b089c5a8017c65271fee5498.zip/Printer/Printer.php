<?php

namespace App\SupportedApps\Printer;

class Printer extends \App\SupportedApps
{
}
