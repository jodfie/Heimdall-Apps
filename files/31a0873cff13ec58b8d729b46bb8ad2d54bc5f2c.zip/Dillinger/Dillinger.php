<?php namespace App\SupportedApps\Dillinger;

class Dillinger extends \App\SupportedApps
{
}
