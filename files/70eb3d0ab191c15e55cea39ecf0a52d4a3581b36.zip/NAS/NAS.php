<?php namespace App\SupportedApps\NAS;

class NAS extends \App\SupportedApps
{
}
