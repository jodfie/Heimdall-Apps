<ul class="livestats">
    <li>
        <strong style="font-size: 0.8em;">Active Series: {!! $active_series_count !!}</strong>
        <strong style="font-size: 0.7em; padding-top: 0.5em;">Unread Chapters: {!! $unread_chapters_count !!}</strong>
    </li>
</ul>