<?php namespace App\SupportedApps\Chevereto;

class Chevereto extends \App\SupportedApps {

}