<?php

namespace App\SupportedApps\Bitwarden;

class Bitwarden extends \App\SupportedApps
{
}
