<?php namespace App\SupportedApps\Serviio;

class Serviio extends \App\SupportedApps
{
}
