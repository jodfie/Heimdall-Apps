<?php

namespace App\SupportedApps\Linkwarden;

class Linkwarden extends \App\SupportedApps
{
}
