<?php namespace App\SupportedApps\TVHeadend;

class TVHeadend extends \App\SupportedApps {

}