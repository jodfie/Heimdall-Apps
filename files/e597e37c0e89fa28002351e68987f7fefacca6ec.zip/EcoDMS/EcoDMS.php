<?php

namespace App\SupportedApps\EcoDMS;

class EcoDMS extends \App\SupportedApps
{
}
