<ul class="livestats">
    <li>
        <span class="title">Channels</span>
        <strong>{!! $activeChannels !!}<span>/{!! $totalChannels !!}</span></strong>
    </li>
