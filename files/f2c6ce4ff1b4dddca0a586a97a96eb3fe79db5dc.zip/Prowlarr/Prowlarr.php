<?php namespace App\SupportedApps\Prowlarr;

class Prowlarr extends \App\SupportedApps {

}