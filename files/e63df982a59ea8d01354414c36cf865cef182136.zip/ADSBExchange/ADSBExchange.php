<?php

namespace App\SupportedApps\ADSBExchange;

class ADSBExchange extends \App\SupportedApps
{
}
