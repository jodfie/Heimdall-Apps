<?php

namespace App\SupportedApps\Podgrab;

class Podgrab extends \App\SupportedApps
{
}
