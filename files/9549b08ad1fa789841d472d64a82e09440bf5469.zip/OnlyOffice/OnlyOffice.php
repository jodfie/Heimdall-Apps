<?php namespace App\SupportedApps\OnlyOffice;

class OnlyOffice extends \App\SupportedApps {

}