<?php

namespace App\SupportedApps\Raneto;

class Raneto extends \App\SupportedApps
{
}
