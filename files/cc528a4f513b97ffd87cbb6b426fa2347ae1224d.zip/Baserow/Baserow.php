<?php

namespace App\SupportedApps\Baserow;

class Baserow extends \App\SupportedApps
{
}
