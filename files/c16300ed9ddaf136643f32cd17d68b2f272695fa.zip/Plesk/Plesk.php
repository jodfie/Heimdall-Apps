<?php namespace App\SupportedApps\Plesk;

class Plesk extends \App\SupportedApps
{
}
