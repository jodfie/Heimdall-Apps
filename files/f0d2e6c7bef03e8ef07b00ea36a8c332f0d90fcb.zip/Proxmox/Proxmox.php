<?php namespace App\SupportedApps\Proxmox;

class Proxmox extends \App\SupportedApps {

}