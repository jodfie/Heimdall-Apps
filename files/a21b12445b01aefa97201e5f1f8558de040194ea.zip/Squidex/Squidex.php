<?php namespace App\SupportedApps\Squidex;

class Squidex extends \App\SupportedApps
{
}
