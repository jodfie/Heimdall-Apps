<?php

namespace App\SupportedApps\Nagios;

class Nagios extends \App\SupportedApps
{
}
