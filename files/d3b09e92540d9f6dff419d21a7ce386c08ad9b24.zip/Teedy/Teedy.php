<?php namespace App\SupportedApps\Teedy;

class Teedy extends \App\SupportedApps {

}