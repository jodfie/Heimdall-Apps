<?php

namespace App\SupportedApps\OliveTin;

class OliveTin extends \App\SupportedApps
{
}
