<?php namespace App\SupportedApps\AsrockRackIPMI;

class AsrockRackIPMI extends \App\SupportedApps {

}