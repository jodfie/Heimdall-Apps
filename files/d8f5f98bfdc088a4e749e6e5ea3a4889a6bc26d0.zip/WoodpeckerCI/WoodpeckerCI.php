<?php

namespace App\SupportedApps\WoodpeckerCI;

class WoodpeckerCI extends \App\SupportedApps
{
}
