<?php namespace App\SupportedApps\Tailscale;

class Tailscale extends \App\SupportedApps {

}