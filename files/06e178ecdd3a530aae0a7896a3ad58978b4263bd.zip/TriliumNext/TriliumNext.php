<?php

namespace App\SupportedApps\TriliumNext;

class TriliumNext extends \App\SupportedApps
{
}
