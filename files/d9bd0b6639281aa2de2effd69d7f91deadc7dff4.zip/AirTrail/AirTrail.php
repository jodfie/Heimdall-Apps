<?php

namespace App\SupportedApps\AirTrail;

class AirTrail extends \App\SupportedApps
{
}
