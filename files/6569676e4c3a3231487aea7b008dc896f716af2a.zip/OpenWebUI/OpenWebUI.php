<?php

namespace App\SupportedApps\OpenWebUI;

class OpenWebUI extends \App\SupportedApps
{
}
