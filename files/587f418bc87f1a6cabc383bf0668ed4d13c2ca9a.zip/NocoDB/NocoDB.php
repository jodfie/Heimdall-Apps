<?php

namespace App\SupportedApps\NocoDB;

class NocoDB extends \App\SupportedApps
{
}
