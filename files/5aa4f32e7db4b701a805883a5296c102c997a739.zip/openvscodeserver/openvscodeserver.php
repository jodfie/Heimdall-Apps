<?php namespace App\SupportedApps\openvscodeserver;

class openvscodeserver extends \App\SupportedApps {

}